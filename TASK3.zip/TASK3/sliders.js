
function myFunction() {


 var x1 = document.getElementById("slid1").value;
 var x2 = document.getElementById("slid2").value;
 var x3 = document.getElementById("slid3").value;
 var x4 = document.getElementById("slid4").value;
 var x5 = document.getElementById("slid5").value;
 var x6 = document.getElementById("slid6").value;

  document.getElementById("p1").innerHTML = + x1;
  document.getElementById("p2").innerHTML = + x2;
  document.getElementById("p3").innerHTML = + x3;
  document.getElementById("p4").innerHTML = + x4;
  document.getElementById("p5").innerHTML = + x5;
  document.getElementById("p6").innerHTML = + x6;

}	
	
	
